package com.example.grocery.controller;

import com.example.grocery.model.CartItem;
import com.example.grocery.repository.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/cart")
public class CartController {
    @Autowired
    private CartItemRepository cartRepo;

    @PostMapping("/add")
    public CartItem addToCart(@RequestBody CartItem item) {
        return cartRepo.save(item);
    }

    @GetMapping("/user/{userId}")
    public List<CartItem> getUserCart(@PathVariable Long userId) {
        return cartRepo.findAll().stream()
            .filter(c -> c.getUser().getId().equals(userId))
            .collect(Collectors.toList());
    }
}
