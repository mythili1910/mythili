package com.example.grocery.controller;

import com.example.grocery.model.DeliverySlot;
import com.example.grocery.repository.DeliverySlotRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/slots")
public class DeliverySlotController {
    @Autowired
    private DeliverySlotRepository slotRepo;

    @GetMapping
    public List<DeliverySlot> availableSlots() {
        return slotRepo.findAll().stream()
            .filter(DeliverySlot::isAvailable)
            .collect(Collectors.toList());
    }
}
