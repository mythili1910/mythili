package com.example.grocery.service;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecommendationService {
    public List<String> getSmartRecommendations(String category) {
        // Stub: Return static recommendations for demo
        return List.of("Apple", "Banana", "Milk");
    }
}
