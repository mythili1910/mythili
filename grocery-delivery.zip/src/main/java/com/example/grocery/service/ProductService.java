package com.example.grocery.service;

import com.example.grocery.model.Product;
import com.example.grocery.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.persistence.EntityNotFoundException;
import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepo;

    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }

    public Product updateStock(Long id, int quantity) {
        Product product = productRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("Product not found"));
        if(product.getStock() < quantity){
            throw new IllegalArgumentException("Not enough stock available");
        }
        product.setStock(product.getStock() - quantity);
        return productRepo.save(product);
    }
}
