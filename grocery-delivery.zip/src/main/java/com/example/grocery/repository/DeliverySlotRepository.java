package com.example.grocery.repository;

import com.example.grocery.model.DeliverySlot;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeliverySlotRepository extends JpaRepository<DeliverySlot, Long> {}
