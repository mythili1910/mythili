# Grocery Delivery System Backend

This is a Spring Boot backend project for an online Grocery Delivery System.

## Features
- Product management with real-time stock updates
- User and cart management
- Scheduled delivery slots
- Smart cart recommendations (stubbed)

## Setup

1. Make sure you have Java 17+ and Maven installed.
2. Run `mvn spring-boot:run` to start the application.
3. Access API at `http://localhost:8080`.

## H2 Database Console

- URL: http://localhost:8080/h2-console
- JDBC URL: jdbc:h2:mem:grocerydb
- Username: sa
- Password: (leave blank)

## APIs

- `GET /products` - List products
- `POST /products/{id}/buy?quantity=` - Buy product (reduce stock)
- `POST /cart/add` - Add to cart
- `GET /cart/user/{userId}` - Get user cart items
- `GET /slots` - Get available delivery slots
